
<?php
@include 'config.php';
if(isset($_POST['submit'])){
  $mechanicname = md5($ $_POST['mechanicname']);
   $email = md5( $_POST['email']);
   $license = mysqli_real_escape_string($conn, $_POST['license']);
   $job = mysqli_real_escape_string($conn, $_POST['job']);
   $further_details = md5($_POST['further_details']);
   
   $select = " SELECT * FROM jobs WHERE email = '$job' && password = '$license' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $error[] = 'job already exist!';
   

  $insert = "INSERT INTO jobs VALUES('$mechanicname','$email', '$license','$job','$further_details')";
  mysqli_query($conn, $insert);
   }
};
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="createjobs.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="form">
    <form method="POST">
    <div class="elem-group">
      <label for="name">Mechanic Name</label>
      <input type="text" id="name" name="mechanicname" placeholder="John Doe" pattern=[A-Z\sa-z]{3,20} required>
    </div>
    <div class="elem-group">
      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="email here: " required>
    </div>
    <div class="license">
      <label for="licensing-num">License</label>
      <input type="license" id="license" name="license" placeholder="Enter licensing: "required>
    </div>
    <hr>
    <div class="elem-group">
      <label for="job-selection">Select Job</label>
      <input type="job" id="job" name="job" placeholder="Enter job: "required>
      </select>
    </div>
    <hr>
    <div class="elem-group">
      <label for="message">Further Details</Details></label>
      <textarea id="message" name="Further Details" placeholder="Tell us anything else that might be important." required></textarea>
    </div>
    <button type="submit" value="submit" name="submit">Submit</button>
    <div class="return">
      <button type="return">Return to Dashboard <a href="admin_page.php"></a></button>
    </div>
</div>
  </form>
</body>
</html>